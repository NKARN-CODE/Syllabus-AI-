"""
Text-to-speech, dispatched by provider. One job: take text, return MP3
(or provider-native) audio bytes.

Every request shape below is confirmed against that provider's own
docs, not guessed:
  - elevenlabs: POST /v1/text-to-speech/{voice_id}, xi-api-key header
  - fish_audio: POST /v1/tts, Authorization: Bearer + model header
  - openai / groq: POST /v1/audio/speech, Authorization: Bearer,
    {model, input, voice} body — groq is OpenAI-compatible, same shape,
    different base URL
  - deepgram: POST /v1/speak?model=..., Authorization: Token header
  - cartesia: POST /tts/bytes, X-API-Key + Cartesia-Version headers,
    nested voice object
  - azure: POST https://{region}.tts.speech.microsoft.com/... with SSML,
    Ocp-Apim-Subscription-Key header — the one provider needing a
    second field (region) beyond key + voice
  - google: POST /v1/text:synthesize?key=..., returns base64 audio
    inside a JSON body rather than raw bytes, unlike every other
    provider here — decoded before returning so callers never see that
    difference
"""
import base64
import requests
import tts_settings

TIMEOUT_SECONDS = 30


class TTSError(Exception):
    pass


def speak(text: str) -> bytes:
    """Synthesize `text` to speech using the saved settings. Returns
    raw audio bytes (MP3 for every provider except Azure, which
    returns the format requested in its header — MP3 here too).
    Raises TTSError with a clear message on any failure."""
    text = (text or "").strip()
    if not text:
        raise TTSError("No text to speak")

    settings = tts_settings.get_settings_raw()
    provider = settings.get("provider") or tts_settings.DEFAULT_PROVIDER
    if provider not in tts_settings.PROVIDERS:
        raise TTSError(f"Unknown TTS provider '{provider}' — check Settings")

    api_key = settings["api_key"]
    if not api_key:
        label = tts_settings.PROVIDERS[provider]["label"]
        raise TTSError(f"No {label} API key saved — add one in Settings")

    voice_id = settings.get("voice_id") or ""
    if tts_settings.PROVIDERS[provider]["voice_required"] and not voice_id:
        label = tts_settings.PROVIDERS[provider]["label"]
        raise TTSError(f"No voice set for {label} — add one in Settings")

    handler = _HANDLERS.get(provider)
    if not handler:
        raise TTSError(f"'{provider}' isn't wired up yet — check Settings")
    return handler(text, api_key, voice_id, settings.get("extra") or "")


def _request(method_label, url, **kwargs):
    try:
        return requests.request("POST", url, timeout=TIMEOUT_SECONDS, **kwargs)
    except requests.RequestException as e:
        raise TTSError(f"Couldn't reach {method_label}: {e}")


def _fail(label, resp, detail_path=None):
    if resp.status_code == 401 or resp.status_code == 403:
        raise TTSError(f"{label} rejected the API key — check it in Settings")
    if resp.status_code == 404:
        raise TTSError(f"{label} couldn't find that voice — check the voice ID in Settings")
    detail = ""
    try:
        j = resp.json()
        detail = (j.get(detail_path) if detail_path else None) or j.get("message") or j.get("error") or str(j)[:200]
    except Exception:
        detail = resp.text[:200]
    raise TTSError(f"{label} returned {resp.status_code}: {detail}")


def _speak_elevenlabs(text, api_key, voice_id, extra):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    resp = _request("ElevenLabs", url,
        headers={"xi-api-key": api_key, "Content-Type": "application/json"},
        json={"text": text, "model_id": "eleven_multilingual_v2"})
    if resp.status_code != 200:
        _fail("ElevenLabs", resp)
    return resp.content


def _speak_fish_audio(text, api_key, voice_id, extra):
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "model": tts_settings.DEFAULT_MODEL}
    body = {"text": text, "format": "mp3"}
    if voice_id:
        body["reference_id"] = voice_id
    resp = _request("Fish Audio", "https://api.fish.audio/v1/tts", headers=headers, json=body)
    if resp.status_code != 200:
        _fail("Fish Audio", resp)
    return resp.content


def _speak_openai_compatible(label, base_url, model):
    def handler(text, api_key, voice_id, extra):
        resp = _request(label, base_url,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": model, "input": text, "voice": voice_id, "response_format": "mp3"})
        if resp.status_code != 200:
            _fail(label, resp)
        return resp.content
    return handler


def _speak_deepgram(text, api_key, voice_id, extra):
    url = f"https://api.deepgram.com/v1/speak?model={voice_id}"
    resp = _request("Deepgram", url,
        headers={"Authorization": f"Token {api_key}", "Content-Type": "application/json"},
        json={"text": text})
    if resp.status_code != 200:
        _fail("Deepgram", resp)
    return resp.content


def _speak_cartesia(text, api_key, voice_id, extra):
    resp = _request("Cartesia", "https://api.cartesia.ai/tts/bytes",
        headers={"X-API-Key": api_key, "Cartesia-Version": "2024-06-10", "Content-Type": "application/json"},
        json={
            "model_id": "sonic-2",
            "transcript": text,
            "voice": {"mode": "id", "id": voice_id},
            "output_format": {"container": "mp3", "sample_rate": 44100, "bit_rate": 128000},
        })
    if resp.status_code != 200:
        _fail("Cartesia", resp)
    return resp.content


def _speak_azure(text, api_key, voice_id, extra):
    region = (extra or "").strip()
    if not region:
        raise TTSError("Azure needs a region too (e.g. eastus) — add it in Settings")
    url = f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1"
    ssml = (
        f"<speak version='1.0' xml:lang='en-US'>"
        f"<voice name='{voice_id}'>{text}</voice></speak>"
    )
    resp = _request("Azure", url,
        headers={
            "Ocp-Apim-Subscription-Key": api_key,
            "Content-Type": "application/ssml+xml",
            "X-Microsoft-OutputFormat": "audio-24khz-96kbitrate-mono-mp3",
        },
        data=ssml.encode("utf-8"))
    if resp.status_code != 200:
        _fail("Azure", resp)
    return resp.content


def _speak_google(text, api_key, voice_id, extra):
    url = f"https://texttospeech.googleapis.com/v1/text:synthesize?key={api_key}"
    lang = "-".join(voice_id.split("-")[:2]) if "-" in voice_id else "en-US"
    resp = _request("Google Cloud", url, json={
        "input": {"text": text},
        "voice": {"languageCode": lang, "name": voice_id},
        "audioConfig": {"audioEncoding": "MP3"},
    })
    if resp.status_code != 200:
        _fail("Google Cloud", resp, detail_path="message")
    audio_b64 = resp.json().get("audioContent", "")
    if not audio_b64:
        raise TTSError("Google Cloud returned no audio content")
    return base64.b64decode(audio_b64)


_HANDLERS = {
    "elevenlabs": _speak_elevenlabs,
    "fish_audio": _speak_fish_audio,
    "openai": _speak_openai_compatible("OpenAI", "https://api.openai.com/v1/audio/speech", "tts-1"),
    "groq": _speak_openai_compatible("Groq", "https://api.groq.com/openai/v1/audio/speech", "playai-tts"),
    "deepgram": _speak_deepgram,
    "cartesia": _speak_cartesia,
    "azure": _speak_azure,
    "google": _speak_google,
}
