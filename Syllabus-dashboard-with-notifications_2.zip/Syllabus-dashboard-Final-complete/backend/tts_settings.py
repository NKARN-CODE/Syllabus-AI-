"""
Text-to-speech settings — provider choice, API key, voice, and one
provider-specific extra field (currently only Azure's region).

Same single-row pattern as ai_settings.py, but kept in its own table
since the chat/tool-calling provider and the voice provider are
independent choices.

The raw api_key is never returned by any read function — only a masked
preview, same convention as ai_settings.py.

PROVIDERS is the registry the frontend picker is built from. Every
entry's key_hint/voice_hint/needs_extra are real, checked against each
provider's own docs — not guessed defaults.
"""
from db import get_conn

DEFAULT_MODEL = "s2.1-pro"  # only used when provider == fish_audio

# label: shown in the dropdown
# key_hint: placeholder text for the API key field
# voice_hint: placeholder text for the voice field ("" if the provider has no voice concept worth exposing)
# needs_extra: label for a second field this provider needs beyond key+voice ("" if none)
# voice_required: whether speak() should refuse to run with no voice set
PROVIDERS = {
    "elevenlabs": {
        "label": "ElevenLabs",
        "key_hint": "Paste your ElevenLabs API key (sk_...)",
        "voice_hint": "Voice ID from your ElevenLabs voice library",
        "needs_extra": "",
        "voice_required": True,
    },
    "fish_audio": {
        "label": "Fish Audio",
        "key_hint": "Paste your Fish Audio API key",
        "voice_hint": "reference_id (optional — blank uses Fish Audio's default voice)",
        "needs_extra": "",
        "voice_required": False,
    },
    "openai": {
        "label": "OpenAI",
        "key_hint": "Paste your OpenAI API key (sk-...)",
        "voice_hint": "alloy, echo, fable, onyx, nova, or shimmer",
        "needs_extra": "",
        "voice_required": True,
    },
    "groq": {
        "label": "Groq",
        "key_hint": "Paste your Groq API key (gsk_...)",
        "voice_hint": "e.g. Fritz-PlayAI — see Groq's playai-tts voice list",
        "needs_extra": "",
        "voice_required": True,
    },
    "deepgram": {
        "label": "Deepgram",
        "key_hint": "Paste your Deepgram API key",
        "voice_hint": "Model name, e.g. aura-2-thalia-en",
        "needs_extra": "",
        "voice_required": True,
    },
    "cartesia": {
        "label": "Cartesia",
        "key_hint": "Paste your Cartesia API key",
        "voice_hint": "Voice ID from your Cartesia voice library",
        "needs_extra": "",
        "voice_required": True,
    },
    "azure": {
        "label": "Azure AI Speech",
        "key_hint": "Paste your Azure Speech resource key",
        "voice_hint": "Voice name, e.g. en-US-JennyNeural",
        "needs_extra": "Region",
        "voice_required": True,
    },
    "google": {
        "label": "Google Cloud Text-to-Speech",
        "key_hint": "Paste your Google Cloud API key",
        "voice_hint": "Voice name, e.g. en-US-Neural2-D",
        "needs_extra": "",
        "voice_required": True,
    },
}

DEFAULT_PROVIDER = "elevenlabs"


def get_settings_raw():
    """Internal use only (tts.py) — includes the real api_key."""
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM tts_settings WHERE id = 1").fetchone()
        if not row:
            return {"provider": DEFAULT_PROVIDER, "api_key": "", "voice_id": "", "extra": ""}
        return dict(row)


def _mask(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "•" * len(key)
    return f"{key[:6]}{'•' * 6}{key[-4:]}"


def get_settings_masked():
    """Safe for the frontend — api_key is replaced with a masked preview."""
    raw = get_settings_raw()
    return {
        "provider": raw["provider"],
        "voice_id": raw["voice_id"],
        "extra": raw["extra"],
        "api_key_set": bool(raw["api_key"]),
        "api_key_preview": _mask(raw["api_key"]),
    }


def list_providers():
    """The registry, for the frontend to build its dropdown from."""
    return [{"id": pid, **info} for pid, info in PROVIDERS.items()]


def save_settings(provider: str, api_key: str, voice_id: str = "", extra: str = ""):
    provider = (provider or "").strip()
    api_key = (api_key or "").strip()
    if provider not in PROVIDERS:
        raise ValueError(f"Unknown provider '{provider}'. Choose one of: {', '.join(PROVIDERS)}")
    if not api_key:
        raise ValueError("API key is required")
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO tts_settings (id, provider, api_key, voice_id, extra)
               VALUES (1, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   provider = excluded.provider,
                   api_key = excluded.api_key,
                   voice_id = excluded.voice_id,
                   extra = excluded.extra""",
            (provider, api_key, voice_id or "", extra or ""),
        )
    return get_settings_masked()
